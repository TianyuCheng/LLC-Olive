int main()
{
    long long arr[5] = { 1, 2, 3, 4, 5 };
    return arr[2];
}
