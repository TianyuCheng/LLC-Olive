int main()
{
    long long i = 0;
    long long ret = 0;
    while (i < 10) {
        ret += i;
        i++;
    }
    return ret;
}
