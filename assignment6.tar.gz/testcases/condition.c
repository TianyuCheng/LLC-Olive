int main()
{
    long long r = 1;
    long long ret;

    if (r > 1)
        r = 10;
    else
        r = 100;
    ret = r;
    return ret;
}
