#include "stdlib.h"
#include "stdio.h"

int main () {
    long long ret = 0;
    long long x = 40;
    long long y = 60;
    ret = x + y;
    return ret;
}
