#include <stdio.h>

int main()
{
    long long a = 1;
    long long b = 2;
    long long ret = (a + b) * (a - b);
    return ret;
}
