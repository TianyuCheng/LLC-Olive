llc-olive
=============

Authors
-------

- Student I
    + Name: Tianyu Cheng
    + EID: tc26752
    + Email: tianyu.cheng@utexas.edu

- Student II
    + Name: Xin Lin
    + EID: xl5224
    + Email: jimmylin@utexas.edu

Usage
-----

To compile our code, type

```
    make
```

References
--------
We referred to the following llvm built-in libraries and theirofficial online documentations:

Acknowledgements
-------
We would like to give many thanks to Prof. Pingali and our Teaching Assistant Mr. Roshan for their teaching and instructions. 
